import tkinter as tk
import pandas as pd
from tkinter.font import BOLD
import util.generic as utl
from pandastable import Table, TableModel
from tkinter import filedialog
from PIL import Image, ImageTk, ImageDraw


class MasterPanel:

    #---------------
    # Genera la tabla 
    #---------------
    def Tabla(self, frame):
        self.file_path = filedialog.askopenfilename(filetypes=[("Archivos Excel", "*.xlsx;*.xlsm")])
        #---------------
        # Lee el archivo exel 
        #---------------
        self.df = pd.read_excel(self.file_path)
        #---------------
        # Crea la tabla 
        #---------------
        self.table = Table(frame, model=TableModel(self.df), width= 650, height= 250)
        self.table.autoResizeColumns()
        #---------------
        # Muestra la tabla 
        #---------------
        self.table.show()

    #---------------
    # Permite guardar los cambios hechos en la tabla
    #---------------
    def SaveTable(self, frame):
        df = self.table
        #---------------
        # Exporta la informacion de la tabla en .csv 
        #---------------
        df.doExport('test.csv', index_col = None)
        #---------------
        # Transforma el documento .csv en .xlsx
        #---------------
        pd.read_csv('test.csv').to_excel('Libro1_Test.xlsx', index=False)
    
    #---------------
    # Permite calcular las calificaciones
    #---------------
    def CalculateTable(self, frame):
        cf = self.table
        #---------------
        # Obtiene los valores de la tabla en un dataFrame
        #---------------
        dfDatos = cf.model.df        
        # Obtiene los valores de la columna: Exa. mitad período
        Em1 = dfDatos.iat[0,4]
        Em2 = dfDatos.iat[1,4]
        Em3 = dfDatos.iat[2,4]
        Em4 = dfDatos.iat[3,4]
        Em5 = dfDatos.iat[4,4]
        # Obtiene los valores de la columna: Exa. final período
        Ef1 = dfDatos.iat[0,5]
        Ef2 = dfDatos.iat[1,5]
        Ef3 = dfDatos.iat[2,5]
        Ef4 = dfDatos.iat[3,5]
        Ef5 = dfDatos.iat[4,5]
        # Asigna los valores de la columna: Exa. Total
        Et1 = ((Em1 + Ef1)*30)/200
        dfDatos.iat[0,3] = Et1
        Et2 = ((Em2 + Ef2)*30)/200
        dfDatos.iat[1,3] = Et2
        Et3 = ((Em3 + Ef3)*30)/200
        dfDatos.iat[2,3] = Et3
        Et4 = ((Em4 + Ef4)*30)/200
        dfDatos.iat[3,3] = Et4
        Et5 = ((Em5 + Ef5)*30)/200
        dfDatos.iat[4,3] = Et5
        # Obtiene los valores de la columna: Act 1
        Act1_1 = dfDatos.iat[0,7]
        Act1_2 = dfDatos.iat[1,7]
        Act1_3 = dfDatos.iat[2,7]
        Act1_4 = dfDatos.iat[3,7]
        Act1_5 = dfDatos.iat[4,7]
        # Obtiene los valores de la columna: Act 2
        Act2_1 = dfDatos.iat[0,8]
        Act2_2 = dfDatos.iat[1,8]
        Act2_3 = dfDatos.iat[2,8]
        Act2_4 = dfDatos.iat[3,8]
        Act2_5 = dfDatos.iat[4,8]
        # Obtiene los valores de la columna: Act 3
        Act3_1 = dfDatos.iat[0,9]
        Act3_2 = dfDatos.iat[1,9]
        Act3_3 = dfDatos.iat[2,9]
        Act3_4 = dfDatos.iat[3,9]
        Act3_5 = dfDatos.iat[4,9]
        # Asigna los valores de la columna: Trabajos
        ActT1 = ((Act1_1 + Act2_1 + Act3_1)*40)/30
        dfDatos.iat[0,6] = ActT1
        ActT2 = ((Act1_2 + Act2_2 + Act3_2)*40)/30
        dfDatos.iat[1,6] = ActT2
        ActT3 = ((Act1_3 + Act2_3 + Act3_3)*40)/30
        dfDatos.iat[2,6] = ActT3
        ActT4 = ((Act1_4 + Act2_4 + Act3_4)*40)/30
        dfDatos.iat[3,6] = ActT4
        ActT5 = ((Act1_5 + Act2_5 + Act3_5)*40)/30
        dfDatos.iat[4,6] = ActT5
        # Obtiene los valores de la columna: Dia 1
        D1_1 = dfDatos.iat[0,11]
        D1_2 = dfDatos.iat[1,11]
        D1_3 = dfDatos.iat[2,11]
        D1_4 = dfDatos.iat[3,11]
        D1_5 = dfDatos.iat[4,11]
        # Obtiene los valores de la columna: Dia 2
        D2_1 = dfDatos.iat[0,12]
        D2_2 = dfDatos.iat[1,12]
        D2_3 = dfDatos.iat[2,12]
        D2_4 = dfDatos.iat[3,12]
        D2_5 = dfDatos.iat[4,12]
        # Obtiene los valores de la columna: Dia 3
        D3_1 = dfDatos.iat[0,13]
        D3_2 = dfDatos.iat[1,13]
        D3_3 = dfDatos.iat[2,13]
        D3_4 = dfDatos.iat[3,13]
        D3_5 = dfDatos.iat[4,13]
        # Obtiene los valores de la columna: Dia 4
        D4_1 = dfDatos.iat[0,14]
        D4_2 = dfDatos.iat[1,14]
        D4_3 = dfDatos.iat[2,14]
        D4_4 = dfDatos.iat[3,14]
        D4_5 = dfDatos.iat[4,14]
        # Obtiene los valores de la columna: Dia 5
        D5_1 = dfDatos.iat[0,15]
        D5_2 = dfDatos.iat[1,15]
        D5_3 = dfDatos.iat[2,15]
        D5_4 = dfDatos.iat[3,15]
        D5_5 = dfDatos.iat[4,15]
        # Obtiene los valores de la columna: Dia 6
        D6_1 = dfDatos.iat[0,16]
        D6_2 = dfDatos.iat[1,16]
        D6_3 = dfDatos.iat[2,16]
        D6_4 = dfDatos.iat[3,16]
        D6_5 = dfDatos.iat[4,16]
        # Asigna los valores de la columna: Asistencia
        DT_1 = ((D1_1 + D2_1 + D3_1 + D4_1 + D5_1 + D6_1)*10)/6
        dfDatos.iat[0,10] = DT_1
        DT_2 = ((D1_2 + D2_2 + D3_2 + D4_2 + D5_2 + D6_2)*10)/6
        dfDatos.iat[1,10] = DT_2
        DT_3 = ((D1_3 + D2_3 + D3_3 + D4_3 + D5_3 + D6_3)*10)/6
        dfDatos.iat[2,10] = DT_3
        DT_4 = ((D1_4 + D2_4 + D3_4 + D4_4 + D5_4 + D6_4)*10)/6
        dfDatos.iat[3,10] = DT_4
        DT_5 = ((D1_5 + D2_5 + D3_5 + D4_5 + D5_5 + D6_5)*10)/6
        dfDatos.iat[4,10] = DT_5
        # Obtiene los valores de la columna: Proyecto final
        PF_1 = dfDatos.iat[0,17]
        PF_2 = dfDatos.iat[1,17]
        PF_3 = dfDatos.iat[2,17]
        PF_4 = dfDatos.iat[3,17]
        PF_5 = dfDatos.iat[4,17]
        # Asigna los valores de la columna: Calificación final
        # Y a su vez verifica si el estudiante tiene mas del 
        # 80% de asistencias y mas de 60 de calificacion final,
        # sino lo reprueba
        CF_1 = Et1 + ActT1 + DT_1 + PF_1
        if DT_1 > 8 and CF_1 > 60:
            dfDatos.iat[0,18] = CF_1
        else:
            dfDatos.iat[0,18] = 'Reprobado'
        CF_2 = Et2 + ActT2 + DT_2 + PF_2
        if DT_2 > 8 and CF_2 > 60:
            dfDatos.iat[1,18] = CF_2
        else:
            dfDatos.iat[1,18] = 'Reprobado'
        CF_3 = Et3 + ActT3 + DT_3 + PF_3
        if DT_3 > 8 and CF_3 > 60:
            dfDatos.iat[2,18] = CF_3
        else:
            dfDatos.iat[2,18] = 'Reprobado'
        CF_4 = Et4 + ActT4 + DT_4 + PF_4
        if DT_4 > 8 and CF_4 > 60:
            dfDatos.iat[3,18] = CF_4
        else:
            dfDatos.iat[3,18] = 'Reprobado'
        CF_5 = Et5 + ActT5 + DT_5 + PF_5
        if DT_5 > 8 and CF_5 > 60:
            dfDatos.iat[4,18] = CF_5
        else:
            dfDatos.iat[4,18] = 'Reprobado'
        #---------------
        # Restablece la tabla con los nuevos valores
        #---------------
        cf.transpose
        cf.redraw()

    #---------------
    # inicia la ventana 
    #---------------    
    def __init__(self):        

        #---------------
        # generar ventana
        #---------------
        self.ventana = tk.Tk()                             
        self.ventana.title('Master panel')
        self.ventana.geometry("1300x730")
        self.ventana.config(bg='#fcfcfc')
        
        #---------------
        # frame superior.
        #---------------
        frame_top = tk.Frame(self.ventana, bd= 0, height= 60, relief= tk.SOLID, pady= 0, bg= '#313745')
        frame_top.pack(side= "top", expand= tk.NO, fill= tk.BOTH)
        #---------------
        # frame lateral.
        # A este sele podran agregar funciones futuras no planeadas por el momento.
        #---------------
        frame_left = tk.Frame(self.ventana, bd= 0, width= 120, relief= tk.SOLID, pady= 0, bg= '#313745')
        frame_left.pack(side= "left", expand= tk.NO, fill= tk.BOTH)
        #---------------
        # Contiene la ruta de la imagen predeterminada
        #---------------
        ruta_imagen_predeterminada = "imagenes\\YO ALGUN PEDO .png"
        #---------------
        # Esta permite colocar una mascara circular en una fotografia la cual puede seleccionar el usuario, y sirve como foto de usuario
        #--------------- 
        def cargar_imagen(event):
            # Filtro de archivo para solo mostrar archivos de imagen
            tipos_archivo = [("Archivos PNG", "*.png"), ("Archivos JPEG", "*.jpeg;*.jpg")]
            ruta_archivo = filedialog.askopenfilename(filetypes=tipos_archivo) # Abrir diálogo de archivo con filtro
            if ruta_archivo:
                imagen = Image.open(ruta_archivo) # Abrir imagen con PIL
                mask = Image.new("L", imagen.size, 0)
                draw = ImageDraw.Draw(mask)
                draw.ellipse((0, 0, imagen.size[0], imagen.size[1]), fill=255)
                imagen.putalpha(mask)
                imagen = imagen.resize((100, 100)) # Redimensionar imagen a 400x400
                imagen = ImageTk.PhotoImage(imagen) # Convertir imagen a formato compatible con Tkinter
                etiqueta.config(image=imagen) # Mostrar imagen en la etiqueta
                etiqueta.image = imagen # Actualizar referencia a la imagen para evitar que sea borrada por el recolector de basura

        # Cargar imagen predeterminada
        image = Image.open(ruta_imagen_predeterminada)
        mask = Image.new("L", image.size, 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0, image.size[0], image.size[1]), fill=255)
        image.putalpha(mask)
        image = image.resize((100, 100), Image.ANTIALIAS)
        photo_imagen = ImageTk.PhotoImage(image)
        
        # Etiqueta que contiene a la imagen
        etiqueta = tk.Label(frame_left, image=photo_imagen, bg="#313745", bd=0, highlightthickness=0)
        etiqueta.image = photo_imagen
        etiqueta.place(x=10, y=10)
        etiqueta.pack()

        # Configurar evento de clic en la etiqueta para cargar la imagen
        etiqueta.bind("<Button-1>", cargar_imagen) # Llamar a la función cargar_imagen() cuando se haga clic en la etiqueta

        #---------------
        # Este es el frame maestro el cual contiene el resto de los widjets en una posicion especifica.
        #---------------
        frame_master = tk.Frame(self.ventana, bd= 0, relief= tk.SOLID, pady= 0, bg= '#777777')
        frame_master.pack(expand= tk.YES, fill= tk.BOTH)
        #---------------
        # frame ubicado en la parte superior izquierda el cual toma una tabla de exel para mostrar
        # esta es posible modificar 
        #---------------
        farme_descripcion = tk.Frame(frame_master, bd= 2, relief= "solid", bg='#FFFFFF', width= 700, height=500)
        farme_descripcion.pack(side='left', expand= tk.NO, padx= 20, pady= 20)
        farme_descripcion.place(x= 10, y= 10 )
        #---------------
        # frame superior derecho muestra un calendario escolar 
        #---------------
        frame_calendario = tk.Frame(frame_master, bd= 2, relief= 'solid', bg= '#777777', width= 455, height= 465)
        frame_calendario.pack(side= 'right',padx= 20, pady= 20)
        frame_calendario.place(x= 730, y= 10)
        #---------------
        # Muestra el calendario escolar
        #---------------
        ima_calendar = Image.open("imagenes\\calendario.png")
        ima_calendar = ima_calendar.resize((445, 455), Image.ANTIALIAS)
        calendario_ima = ImageTk.PhotoImage(ima_calendar)
        label = tk.Label(frame_calendario, image=calendario_ima, bg="#313745", bd=0, highlightthickness=0)
        label.image = calendario_ima
        label.place(x=1, y=1)
        label.pack()
        #---------------
        # frame inferior izquierdo este debera contener las clases las cuales tendran la funcion que al dar click
        # en una de ellas abra un archivo de exel respectivo a la clase seleccionada.
        #---------------
        # frame_clases = tk.Frame(frame_master, bd= 0, relief= tk.SOLID, bg= '#FFFFFF', width= 700, height= 340)
        # frame_clases.pack(side= 'right',padx= 20, pady= 20)
        # frame_clases.place(x= 10, y= 320)
        #---------------
        # Boton para abrir archivo .xlsx en la tabla
        #---------------
        boton_Abrir = tk.Button(frame_master, text= "Abrir archivo", width= 14, font= ("Gidole Regular", 15), bd= 2, relief= "solid", bg = '#777777', fg= 'black', command= lambda:self.Tabla(farme_descripcion))
        boton_Abrir.pack(side= "right" ,padx= 200, pady= 10)
        boton_Abrir.place(x= 190, y= 540)
        boton_Abrir.bind("<Return>", (lambda event: self.Tabla(farme_descripcion)))
        #---------------
        # Boton para guardar cambios en la tabla
        #--------------
        boton_Save = tk.Button(frame_master, text= "Guardar cambios", font= ("Gidole Regular", 15), bd= 2, relief= "solid", bg = '#777777', fg= 'black', command= lambda:self.SaveTable(farme_descripcion))
        boton_Save.pack(side= "right" ,padx= 200, pady= 10)
        boton_Save.place(x= 390, y= 540)
        #---------------
        # Boton para calcular las calificaciones de la tabla
        #--------------
        boton_Calcular = tk.Button(frame_master, text= "Calcular calif", font= ("Gidole Regular", 15), bd= 2, relief= "solid", bg = '#777777', fg= 'black', command= lambda:self.CalculateTable(farme_descripcion))
        boton_Calcular.pack(side= "right" ,padx= 200, pady= 10)
        boton_Calcular.place(x= 590, y= 540)
        #---------------
        
        #--------------
        self.ventana.mainloop()