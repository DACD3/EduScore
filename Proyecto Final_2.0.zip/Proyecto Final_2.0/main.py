#Jose Antonio Garcia Peña.
# 04/04/2023
# NO TOCAR. 
# Ejecutor del programa
#---------------
# para usar probar el formulario login.        
#--------------
from Formulario.F_Login import App
App()
#---------------
# para usar probar el formulario maestro.        
#--------------
# from Formulario.F_Master import MasterPanel
# MasterPanel()
#---------------
# para usar probar el formulario de registro.        
#--------------
# from Formulario.F_Registrar import Registrar_Panel
# Registrar_Panel()